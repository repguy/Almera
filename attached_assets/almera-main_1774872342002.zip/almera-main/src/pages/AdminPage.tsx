import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { useToast } from '@/hooks/use-toast';
import { LayoutDashboard, ShoppingCart, Settings, FileText, LogOut, ArrowLeft, Eye } from 'lucide-react';
import { motion } from 'framer-motion';

const AdminPage = () => {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) { navigate('/auth'); return; }
    supabase.rpc('has_role', { _user_id: user.id, _role: 'admin' }).then(({ data }) => {
      if (!data) { navigate('/'); toast({ title: 'Access denied', variant: 'destructive' }); return; }
      setIsAdmin(true);
      setLoading(false);
    });
  }, [user, navigate, toast]);

  if (loading || !isAdmin) return <div className="min-h-screen flex items-center justify-center bg-background"><div className="animate-spin w-8 h-8 border-2 border-primary border-t-transparent rounded-full" /></div>;

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 bg-background/80 backdrop-blur-lg border-b border-border px-4 h-14 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate('/')} className="text-muted-foreground hover:text-foreground"><ArrowLeft size={20} /></button>
          <h1 className="font-display text-lg font-bold text-foreground">Almera Admin</h1>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="sm" onClick={() => navigate('/')}><Eye size={16} className="mr-1" /> View Site</Button>
          <Button variant="ghost" size="sm" onClick={signOut}><LogOut size={16} /></Button>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6 max-w-6xl">
        <Tabs defaultValue="dashboard" className="space-y-6">
          <TabsList className="w-full justify-start overflow-x-auto">
            <TabsTrigger value="dashboard"><LayoutDashboard size={16} className="mr-1" /> Dashboard</TabsTrigger>
            <TabsTrigger value="orders"><ShoppingCart size={16} className="mr-1" /> Orders</TabsTrigger>
            <TabsTrigger value="settings"><Settings size={16} className="mr-1" /> Settings</TabsTrigger>
            <TabsTrigger value="legal"><FileText size={16} className="mr-1" /> Legal Pages</TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard"><DashboardTab /></TabsContent>
          <TabsContent value="orders"><OrdersTab /></TabsContent>
          <TabsContent value="settings"><SettingsTab /></TabsContent>
          <TabsContent value="legal"><LegalTab /></TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

// ——— DASHBOARD ———
const DashboardTab = () => {
  const [stats, setStats] = useState({ total: 0, revenue: 0, pending: 0, delivered: 0 });

  useEffect(() => {
    supabase.from('orders').select('total, status').then(({ data }) => {
      if (!data) return;
      setStats({
        total: data.length,
        revenue: data.filter(o => o.status === 'delivered').reduce((s, o) => s + o.total, 0),
        pending: data.filter(o => o.status === 'pending').length,
        delivered: data.filter(o => o.status === 'delivered').length,
      });
    });
  }, []);

  const cards = [
    { label: 'Total Orders', value: stats.total, color: 'text-foreground' },
    { label: 'Revenue', value: `Rs. ${stats.revenue.toLocaleString()}`, color: 'text-green-600' },
    { label: 'Pending', value: stats.pending, color: 'text-yellow-600' },
    { label: 'Delivered', value: stats.delivered, color: 'text-primary' },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {cards.map(c => (
        <motion.div key={c.label} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-card rounded-xl border border-border p-5">
          <p className="text-xs text-muted-foreground uppercase tracking-wider">{c.label}</p>
          <p className={`text-2xl font-display font-bold mt-1 ${c.color}`}>{c.value}</p>
        </motion.div>
      ))}
    </div>
  );
};

// ——— ORDERS ———
const OrdersTab = () => {
  const [orders, setOrders] = useState<any[]>([]);
  const [filter, setFilter] = useState('all');
  const { toast } = useToast();

  const loadOrders = () => {
    let q = supabase.from('orders').select('*').order('created_at', { ascending: false });
    if (filter !== 'all') q = q.eq('status', filter);
    q.then(({ data }) => setOrders(data || []));
  };

  useEffect(() => { loadOrders(); }, [filter]);

  const updateStatus = async (id: string, status: string) => {
    await supabase.from('orders').update({ status } as any).eq('id', id);
    toast({ title: 'Status updated' });
    loadOrders();
  };

  const updatePayment = async (id: string, payment_status: string) => {
    const update: any = { payment_status };
    if (payment_status === 'verified') update.status = 'confirmed';
    await supabase.from('orders').update(update).eq('id', id);
    toast({ title: 'Payment ' + payment_status });
    loadOrders();
  };

  const statusColors: Record<string, string> = {
    pending: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400',
    confirmed: 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400',
    shipped: 'bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400',
    out_for_delivery: 'bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400',
    delivered: 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400',
    cancelled: 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400',
  };

  return (
    <div className="space-y-4">
      <div className="flex gap-2 flex-wrap">
        {['all','pending','confirmed','shipped','out_for_delivery','delivered','cancelled'].map(s => (
          <Button key={s} variant={filter === s ? 'default' : 'outline'} size="sm" onClick={() => setFilter(s)} className="text-xs capitalize">
            {s.replace(/_/g, ' ')}
          </Button>
        ))}
      </div>
      <div className="rounded-xl border border-border overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Order</TableHead>
              <TableHead>Customer</TableHead>
              <TableHead>Total</TableHead>
              <TableHead>Payment</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {orders.map(o => (
              <TableRow key={o.id}>
                <TableCell>
                  <p className="font-mono text-xs text-foreground">{o.order_number}</p>
                  <p className="text-[10px] text-muted-foreground">{new Date(o.created_at).toLocaleDateString()}</p>
                </TableCell>
                <TableCell>
                  <p className="text-sm text-foreground">{o.customer_name}</p>
                  <p className="text-xs text-muted-foreground">{o.customer_phone}</p>
                </TableCell>
                <TableCell className="font-semibold text-sm">Rs. {o.total.toLocaleString()}</TableCell>
                <TableCell>
                  <div className="space-y-1">
                    <Badge variant="outline" className="text-[10px]">{o.payment_method.replace('_', ' ')}</Badge>
                    {o.payment_status === 'pending' && o.payment_method !== 'cod' && (
                      <div className="flex gap-1">
                        <Button size="sm" variant="outline" className="h-6 text-[10px] text-green-600" onClick={() => updatePayment(o.id, 'verified')}>✓ Verify</Button>
                        <Button size="sm" variant="outline" className="h-6 text-[10px] text-red-600" onClick={() => updatePayment(o.id, 'rejected')}>✗ Reject</Button>
                      </div>
                    )}
                    {o.payment_status !== 'pending' && (
                      <Badge className={`text-[10px] ${o.payment_status === 'verified' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                        {o.payment_status}
                      </Badge>
                    )}
                  </div>
                </TableCell>
                <TableCell>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full ${statusColors[o.status] || ''}`}>
                    {o.status.replace(/_/g, ' ')}
                  </span>
                </TableCell>
                <TableCell>
                  <Select value={o.status} onValueChange={(v) => updateStatus(o.id, v)}>
                    <SelectTrigger className="h-8 text-xs w-[130px]"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {['pending','confirmed','shipped','out_for_delivery','delivered','cancelled'].map(s => (
                        <SelectItem key={s} value={s} className="text-xs capitalize">{s.replace(/_/g, ' ')}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </TableCell>
              </TableRow>
            ))}
            {orders.length === 0 && (
              <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground py-8">No orders found</TableCell></TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};

// ——— SETTINGS ———
const SettingsTab = () => {
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    supabase.from('site_settings').select('key, value').then(({ data }) => {
      if (data) {
        const s: Record<string, string> = {};
        data.forEach(r => { s[r.key] = r.value; });
        setSettings(s);
      }
    });
  }, []);

  const update = (key: string, value: string) => setSettings(s => ({ ...s, [key]: value }));

  const save = async () => {
    setSaving(true);
    for (const [key, value] of Object.entries(settings)) {
      await supabase.from('site_settings').update({ value } as any).eq('key', key);
    }
    toast({ title: 'Settings saved!' });
    setSaving(false);
  };

  return (
    <div className="space-y-6 max-w-2xl">
      <div className="bg-card rounded-xl border border-border p-6 space-y-4">
        <h3 className="font-display font-semibold text-foreground">Store Controls</h3>
        <div className="flex items-center justify-between">
          <div><Label>Pause Orders</Label><p className="text-xs text-muted-foreground">Disable new orders temporarily</p></div>
          <Switch checked={settings.orders_paused === 'true'} onCheckedChange={v => update('orders_paused', v ? 'true' : 'false')} />
        </div>
        <div className="flex items-center justify-between">
          <div><Label>Site-wide Sale</Label><p className="text-xs text-muted-foreground">Enable sale banner</p></div>
          <Switch checked={settings.sale_active === 'true'} onCheckedChange={v => update('sale_active', v ? 'true' : 'false')} />
        </div>
        {settings.sale_active === 'true' && (
          <div>
            <Label>Sale Percentage</Label>
            <Input type="number" value={settings.sale_percent || ''} onChange={e => update('sale_percent', e.target.value)} />
          </div>
        )}
      </div>

      <div className="bg-card rounded-xl border border-border p-6 space-y-4">
        <h3 className="font-display font-semibold text-foreground">Easypaisa Details</h3>
        <div className="grid grid-cols-2 gap-4">
          <div><Label>Account Name</Label><Input value={settings.easypaisa_name || ''} onChange={e => update('easypaisa_name', e.target.value)} /></div>
          <div><Label>Account Number</Label><Input value={settings.easypaisa_number || ''} onChange={e => update('easypaisa_number', e.target.value)} /></div>
        </div>
      </div>

      <div className="bg-card rounded-xl border border-border p-6 space-y-4">
        <h3 className="font-display font-semibold text-foreground">Bank Transfer Details</h3>
        <div className="grid grid-cols-2 gap-4">
          <div><Label>Bank Name</Label><Input value={settings.bank_name || ''} onChange={e => update('bank_name', e.target.value)} /></div>
          <div><Label>Account Title</Label><Input value={settings.bank_account_title || ''} onChange={e => update('bank_account_title', e.target.value)} /></div>
          <div><Label>Account Number</Label><Input value={settings.bank_account_number || ''} onChange={e => update('bank_account_number', e.target.value)} /></div>
          <div><Label>IBAN</Label><Input value={settings.bank_iban || ''} onChange={e => update('bank_iban', e.target.value)} /></div>
        </div>
      </div>

      <div className="bg-card rounded-xl border border-border p-6 space-y-4">
        <h3 className="font-display font-semibold text-foreground">Delivery & Fees</h3>
        <div className="grid grid-cols-2 gap-4">
          <div><Label>Delivery Fee (PKR)</Label><Input type="number" value={settings.delivery_fee || ''} onChange={e => update('delivery_fee', e.target.value)} /></div>
          <div><Label>COD Fee (%)</Label><Input type="number" value={settings.cod_fee_percent || ''} onChange={e => update('cod_fee_percent', e.target.value)} /></div>
        </div>
      </div>

      <div className="bg-card rounded-xl border border-border p-6 space-y-4">
        <h3 className="font-display font-semibold text-foreground">WhatsApp</h3>
        <div><Label>WhatsApp Number (e.g. 923001234567)</Label><Input value={settings.whatsapp_number || ''} onChange={e => update('whatsapp_number', e.target.value)} /></div>
      </div>

      <Button onClick={save} disabled={saving} className="gradient-gold text-primary-foreground">
        {saving ? 'Saving...' : 'Save Settings'}
      </Button>
    </div>
  );
};

// ——— LEGAL ———
const LegalTab = () => {
  const [pages, setPages] = useState<any[]>([]);
  const [editing, setEditing] = useState<any>(null);
  const { toast } = useToast();

  useEffect(() => {
    supabase.from('legal_pages').select('*').then(({ data }) => setPages(data || []));
  }, []);

  const save = async () => {
    if (!editing) return;
    await supabase.from('legal_pages').update({ title: editing.title, content: editing.content } as any).eq('id', editing.id);
    toast({ title: 'Page updated!' });
    setPages(ps => ps.map(p => p.id === editing.id ? editing : p));
    setEditing(null);
  };

  return (
    <div className="space-y-4 max-w-3xl">
      {!editing ? (
        pages.map(p => (
          <div key={p.id} className="bg-card rounded-xl border border-border p-5 flex items-center justify-between">
            <div>
              <p className="font-medium text-foreground">{p.title}</p>
              <p className="text-xs text-muted-foreground">/{p.slug}</p>
            </div>
            <Button variant="outline" size="sm" onClick={() => setEditing({ ...p })}>Edit</Button>
          </div>
        ))
      ) : (
        <div className="bg-card rounded-xl border border-border p-6 space-y-4">
          <div><Label>Title</Label><Input value={editing.title} onChange={e => setEditing({ ...editing, title: e.target.value })} /></div>
          <div>
            <Label>Content (HTML)</Label>
            <textarea
              value={editing.content}
              onChange={e => setEditing({ ...editing, content: e.target.value })}
              className="w-full min-h-[300px] p-3 rounded-lg border border-border bg-background text-foreground text-sm font-mono resize-y"
            />
          </div>
          <div className="flex gap-2">
            <Button onClick={save} className="gradient-gold text-primary-foreground">Save</Button>
            <Button variant="outline" onClick={() => setEditing(null)}>Cancel</Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminPage;
