import { useState } from 'react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import CartDrawer from '@/components/CartDrawer';
import { supabase } from '@/integrations/supabase/client';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search, Package, CheckCircle2, Truck, MapPin, CircleDot } from 'lucide-react';
import { motion } from 'framer-motion';

const statusSteps = [
  { key: 'pending', label: 'Pending', icon: CircleDot },
  { key: 'confirmed', label: 'Confirmed', icon: CheckCircle2 },
  { key: 'shipped', label: 'Shipped', icon: Package },
  { key: 'out_for_delivery', label: 'Out for Delivery', icon: Truck },
  { key: 'delivered', label: 'Delivered', icon: MapPin },
];

const TrackOrderPage = () => {
  const [query, setQuery] = useState('');
  const [order, setOrder] = useState<any>(null);
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;
    setLoading(true);
    setError('');
    setOrder(null);

    const { data, error: err } = await supabase
      .from('orders')
      .select('*')
      .or(`order_number.eq.${query.trim().toUpperCase()},customer_phone.eq.${query.trim()}`)
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (err || !data) {
      setError('Order not found. Check your order number or phone.');
      setLoading(false);
      return;
    }

    setOrder(data);
    const { data: oi } = await supabase.from('order_items').select('*').eq('order_id', data.id);
    setItems(oi || []);
    setLoading(false);
  };

  const currentStep = order ? statusSteps.findIndex(s => s.key === order.status) : -1;
  const formatPrice = (p: number) => `Rs. ${p.toLocaleString()}`;

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="container mx-auto px-4 py-12 max-w-2xl">
        <h1 className="font-display text-2xl md:text-3xl font-bold text-foreground mb-2 text-center">Track Your Order</h1>
        <p className="text-muted-foreground text-center mb-8 text-sm">Enter your order number or phone number</p>

        <form onSubmit={handleSearch} className="flex gap-2 mb-8">
          <Input value={query} onChange={e => setQuery(e.target.value)} placeholder="ALM-XXXXXX-XXXX or 03XX..." className="flex-1" />
          <Button type="submit" disabled={loading} className="gradient-gold text-primary-foreground">
            <Search size={18} />
          </Button>
        </form>

        {error && <p className="text-center text-destructive text-sm">{error}</p>}

        {order && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
            <div className="bg-card rounded-xl border border-border p-6">
              <div className="flex justify-between items-start mb-6">
                <div>
                  <p className="font-display font-semibold text-foreground">{order.order_number}</p>
                  <p className="text-xs text-muted-foreground">{new Date(order.created_at).toLocaleDateString('en-PK', { dateStyle: 'long' })}</p>
                </div>
                <span className={`text-xs px-3 py-1 rounded-full font-medium ${
                  order.status === 'delivered' ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400' :
                  order.status === 'cancelled' ? 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400' :
                  'bg-primary/10 text-primary'
                }`}>
                  {order.status.replace(/_/g, ' ').replace(/\b\w/g, (l: string) => l.toUpperCase())}
                </span>
              </div>

              {order.status !== 'cancelled' && (
                <div className="flex items-center justify-between mb-6">
                  {statusSteps.map((step, i) => {
                    const Icon = step.icon;
                    const isActive = i <= currentStep;
                    return (
                      <div key={step.key} className="flex flex-col items-center gap-1 flex-1">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center transition-colors ${
                          isActive ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'
                        }`}>
                          <Icon size={16} />
                        </div>
                        <span className={`text-[10px] text-center ${isActive ? 'text-foreground font-medium' : 'text-muted-foreground'}`}>
                          {step.label}
                        </span>
                        {i < statusSteps.length - 1 && (
                          <div className={`hidden`} />
                        )}
                      </div>
                    );
                  })}
                </div>
              )}

              <div className="space-y-3">
                {items.map(item => (
                  <div key={item.id} className="flex gap-3">
                    <img src={item.product_image} alt={item.product_name} className="w-12 h-14 object-cover rounded" />
                    <div className="flex-1">
                      <p className="text-sm font-medium text-foreground">{item.product_name}</p>
                      <p className="text-xs text-muted-foreground">{item.size} · {item.color} × {item.quantity}</p>
                    </div>
                    <p className="text-sm font-semibold text-primary">{formatPrice(item.total_price)}</p>
                  </div>
                ))}
              </div>

              <div className="mt-4 pt-4 border-t border-border flex justify-between text-sm">
                <span className="text-muted-foreground">Total</span>
                <span className="font-display font-semibold text-foreground">{formatPrice(order.total)}</span>
              </div>
            </div>
          </motion.div>
        )}
      </main>
      <Footer />
      <CartDrawer />
    </div>
  );
};

export default TrackOrderPage;
