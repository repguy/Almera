import Navbar from '@/components/Navbar';
import HeroSection from '@/components/home/HeroSection';
import CategoriesSection from '@/components/home/CategoriesSection';
import FeaturedProducts from '@/components/home/FeaturedProducts';
import ReviewMarquee from '@/components/home/ReviewMarquee';
import Footer from '@/components/Footer';
import CartDrawer from '@/components/CartDrawer';
import WhatsAppWidget from '@/components/WhatsAppWidget';

const Index = () => (
  <div className="min-h-screen">
    <Navbar />
    <main>
      <HeroSection />
      <CategoriesSection />
      <FeaturedProducts />
      <ReviewMarquee />
    </main>
    <Footer />
    <CartDrawer />
    <WhatsAppWidget />
  </div>
);

export default Index;
