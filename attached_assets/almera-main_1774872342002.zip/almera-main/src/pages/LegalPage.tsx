import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import CartDrawer from '@/components/CartDrawer';
import { supabase } from '@/integrations/supabase/client';
import { Skeleton } from '@/components/ui/skeleton';

const LegalPage = () => {
  const { slug } = useParams<{ slug: string }>();
  const [page, setPage] = useState<{ title: string; content: string } | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!slug) return;
    setLoading(true);
    supabase.from('legal_pages').select('title, content').eq('slug', slug).maybeSingle()
      .then(({ data }) => { setPage(data); setLoading(false); });
  }, [slug]);

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="container mx-auto px-4 py-12 max-w-3xl">
        {loading ? (
          <div className="space-y-4">
            <Skeleton className="h-10 w-1/2" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-3/4" />
            <Skeleton className="h-4 w-5/6" />
          </div>
        ) : page ? (
          <div>
            <h1 className="font-display text-3xl font-bold text-foreground mb-8">{page.title}</h1>
            <div
              className="prose prose-sm dark:prose-invert max-w-none text-foreground/90"
              dangerouslySetInnerHTML={{ __html: page.content }}
            />
          </div>
        ) : (
          <p className="text-center text-muted-foreground">Page not found.</p>
        )}
      </main>
      <Footer />
      <CartDrawer />
    </div>
  );
};

export default LegalPage;
