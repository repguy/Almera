import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import CartDrawer from '@/components/CartDrawer';
import { useCart } from '@/context/CartContext';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { motion, AnimatePresence } from 'framer-motion';
import { Check, Upload, Loader2, Copy, ArrowLeft } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const CheckoutPage = () => {
  const { items, totalPrice, clearCart } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const [paymentMethod, setPaymentMethod] = useState('cod');
  const [screenshot, setScreenshot] = useState<File | null>(null);
  const [screenshotPreview, setScreenshotPreview] = useState('');
  const [loading, setLoading] = useState(false);
  const [orderPlaced, setOrderPlaced] = useState(false);
  const [orderNumber, setOrderNumber] = useState('');
  const [settings, setSettings] = useState<Record<string, string>>({});

  const [form, setForm] = useState({
    name: '', email: '', phone: '', address: '', city: '', notes: ''
  });

  useEffect(() => {
    supabase.from('site_settings').select('key, value').then(({ data }) => {
      if (data) {
        const s: Record<string, string> = {};
        data.forEach(r => { s[r.key] = r.value; });
        setSettings(s);
      }
    });
  }, []);

  useEffect(() => {
    if (items.length === 0 && !orderPlaced) navigate('/shop');
  }, [items, orderPlaced, navigate]);

  const deliveryFee = parseInt(settings.delivery_fee || '200');
  const codFeePercent = parseInt(settings.cod_fee_percent || '10');
  const codFee = paymentMethod === 'cod' ? Math.round(totalPrice * codFeePercent / 100) : 0;
  const grandTotal = totalPrice + deliveryFee + codFee;

  const formatPrice = (p: number) => `Rs. ${p.toLocaleString()}`;

  const handleScreenshot = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setScreenshot(file);
      setScreenshotPreview(URL.createObjectURL(file));
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: 'Copied!', description: text });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.phone || !form.address || !form.city) {
      toast({ title: 'Missing fields', description: 'Please fill all required fields.', variant: 'destructive' });
      return;
    }
    if ((paymentMethod === 'easypaisa' || paymentMethod === 'bank_transfer') && !screenshot) {
      toast({ title: 'Screenshot required', description: 'Please upload your payment screenshot.', variant: 'destructive' });
      return;
    }

    setLoading(true);
    try {
      let screenshotUrl = '';
      if (screenshot) {
        const ext = screenshot.name.split('.').pop();
        const path = `${user?.id || 'guest'}/${Date.now()}.${ext}`;
        const { error: uploadErr } = await supabase.storage.from('payment-screenshots').upload(path, screenshot);
        if (uploadErr) throw uploadErr;
        screenshotUrl = path;
      }

      const { data: order, error: orderErr } = await supabase.from('orders').insert({
        user_id: user?.id || null,
        order_number: 'TEMP',
        payment_method: paymentMethod,
        payment_screenshot_url: screenshotUrl || null,
        subtotal: totalPrice,
        delivery_fee: deliveryFee,
        cod_fee: codFee,
        total: grandTotal,
        customer_name: form.name,
        customer_email: form.email || null,
        customer_phone: form.phone,
        shipping_address: form.address,
        shipping_city: form.city,
        notes: form.notes || null,
      } as any).select('id, order_number').single();

      if (orderErr) throw orderErr;

      const orderItems = items.map(item => ({
        order_id: order.id,
        product_id: item.product.id,
        product_name: item.product.name,
        product_image: item.product.images[0],
        size: item.selectedSize,
        color: item.selectedColor,
        quantity: item.quantity,
        unit_price: item.product.discountedPrice,
        total_price: item.product.discountedPrice * item.quantity,
      }));

      const { error: itemsErr } = await supabase.from('order_items').insert(orderItems as any);
      if (itemsErr) throw itemsErr;

      setOrderNumber(order.order_number);
      setOrderPlaced(true);
      clearCart();
    } catch (err: any) {
      toast({ title: 'Error', description: err.message || 'Something went wrong', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  if (orderPlaced) {
    return (
      <div className="min-h-screen">
        <Navbar />
        <div className="flex flex-col items-center justify-center min-h-[60vh] px-4">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: 'spring', stiffness: 200, damping: 15 }}
            className="w-20 h-20 rounded-full bg-green-500 flex items-center justify-center mb-6"
          >
            <Check size={40} className="text-white" />
          </motion.div>
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="font-display text-2xl md:text-3xl font-bold text-foreground mb-2"
          >
            Order Placed!
          </motion.h1>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="text-muted-foreground mb-1"
          >
            Order #{orderNumber}
          </motion.p>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6 }}
            className="text-sm text-muted-foreground mb-8 text-center max-w-md"
          >
            {paymentMethod === 'cod'
              ? 'Your order will be confirmed shortly. Pay on delivery.'
              : 'We\'ll verify your payment and confirm your order soon.'}
          </motion.p>
          <div className="flex gap-3">
            <Button variant="outline" onClick={() => navigate('/shop')}>Continue Shopping</Button>
            <Button onClick={() => navigate('/track-order')} className="gradient-gold text-primary-foreground">Track Order</Button>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="container mx-auto px-4 py-8 max-w-4xl">
        <button onClick={() => navigate(-1)} className="flex items-center gap-2 text-muted-foreground hover:text-foreground mb-6 text-sm">
          <ArrowLeft size={16} /> Back
        </button>
        <h1 className="font-display text-2xl md:text-3xl font-bold text-foreground mb-8">Checkout</h1>

        <form onSubmit={handleSubmit} className="grid md:grid-cols-5 gap-8">
          {/* Left: Form */}
          <div className="md:col-span-3 space-y-6">
            <div className="bg-card rounded-xl border border-border p-6 space-y-4">
              <h2 className="font-display text-lg font-semibold text-foreground">Delivery Details</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Full Name *</Label>
                  <Input id="name" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} required />
                </div>
                <div>
                  <Label htmlFor="phone">Phone *</Label>
                  <Input id="phone" value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} placeholder="03XX-XXXXXXX" required />
                </div>
                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} />
                </div>
                <div>
                  <Label htmlFor="city">City *</Label>
                  <Input id="city" value={form.city} onChange={e => setForm(f => ({ ...f, city: e.target.value }))} required />
                </div>
              </div>
              <div>
                <Label htmlFor="address">Full Address *</Label>
                <Input id="address" value={form.address} onChange={e => setForm(f => ({ ...f, address: e.target.value }))} required />
              </div>
              <div>
                <Label htmlFor="notes">Order Notes</Label>
                <Input id="notes" value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} placeholder="Any special instructions..." />
              </div>
            </div>

            <div className="bg-card rounded-xl border border-border p-6 space-y-4">
              <h2 className="font-display text-lg font-semibold text-foreground">Payment Method</h2>
              <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod} className="space-y-3">
                <label className="flex items-center gap-3 p-3 rounded-lg border border-border hover:border-primary/50 cursor-pointer transition-colors">
                  <RadioGroupItem value="cod" id="cod" />
                  <div>
                    <p className="font-medium text-foreground text-sm">Cash on Delivery</p>
                    <p className="text-xs text-muted-foreground">{codFeePercent}% handling fee applies</p>
                  </div>
                </label>
                <label className="flex items-center gap-3 p-3 rounded-lg border border-border hover:border-primary/50 cursor-pointer transition-colors">
                  <RadioGroupItem value="easypaisa" id="easypaisa" />
                  <div>
                    <p className="font-medium text-foreground text-sm">Easypaisa / JazzCash</p>
                    <p className="text-xs text-muted-foreground">Send payment & upload screenshot</p>
                  </div>
                </label>
                <label className="flex items-center gap-3 p-3 rounded-lg border border-border hover:border-primary/50 cursor-pointer transition-colors">
                  <RadioGroupItem value="bank_transfer" id="bank_transfer" />
                  <div>
                    <p className="font-medium text-foreground text-sm">Bank Transfer</p>
                    <p className="text-xs text-muted-foreground">Transfer & upload receipt</p>
                  </div>
                </label>
              </RadioGroup>

              <AnimatePresence mode="wait">
                {paymentMethod === 'easypaisa' && (
                  <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="space-y-3 overflow-hidden">
                    <div className="bg-muted rounded-lg p-4 space-y-2">
                      <p className="text-sm font-medium text-foreground">Send {formatPrice(grandTotal)} to:</p>
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm text-muted-foreground">Account: <span className="text-foreground font-mono">{settings.easypaisa_number || '03001234567'}</span></p>
                          <p className="text-sm text-muted-foreground">Name: {settings.easypaisa_name || 'Almera Store'}</p>
                        </div>
                        <Button type="button" variant="ghost" size="icon" onClick={() => copyToClipboard(settings.easypaisa_number || '03001234567')}>
                          <Copy size={16} />
                        </Button>
                      </div>
                    </div>
                  </motion.div>
                )}
                {paymentMethod === 'bank_transfer' && (
                  <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="space-y-3 overflow-hidden">
                    <div className="bg-muted rounded-lg p-4 space-y-2">
                      <p className="text-sm font-medium text-foreground">Transfer {formatPrice(grandTotal)} to:</p>
                      <div className="space-y-1 text-sm">
                        <p className="text-muted-foreground">Bank: <span className="text-foreground">{settings.bank_name || 'Meezan Bank'}</span></p>
                        <p className="text-muted-foreground">Title: <span className="text-foreground">{settings.bank_account_title || 'Almera Store'}</span></p>
                        <div className="flex items-center justify-between">
                          <p className="text-muted-foreground">Account: <span className="text-foreground font-mono">{settings.bank_account_number || '1234567890'}</span></p>
                          <Button type="button" variant="ghost" size="icon" onClick={() => copyToClipboard(settings.bank_account_number || '1234567890')}>
                            <Copy size={16} />
                          </Button>
                        </div>
                        <p className="text-muted-foreground">IBAN: <span className="text-foreground font-mono text-xs">{settings.bank_iban || 'PK00MEZN0000001234567890'}</span></p>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {(paymentMethod === 'easypaisa' || paymentMethod === 'bank_transfer') && (
                <div className="space-y-2">
                  <Label>Payment Screenshot *</Label>
                  <label className="flex flex-col items-center gap-2 p-6 border-2 border-dashed border-border rounded-lg cursor-pointer hover:border-primary/50 transition-colors">
                    {screenshotPreview ? (
                      <img src={screenshotPreview} alt="Screenshot" className="max-h-40 rounded-md" />
                    ) : (
                      <>
                        <Upload size={24} className="text-muted-foreground" />
                        <p className="text-sm text-muted-foreground">Click to upload screenshot</p>
                      </>
                    )}
                    <input type="file" accept="image/*" onChange={handleScreenshot} className="hidden" />
                  </label>
                </div>
              )}
            </div>
          </div>

          {/* Right: Summary */}
          <div className="md:col-span-2">
            <div className="bg-card rounded-xl border border-border p-6 space-y-4 sticky top-24">
              <h2 className="font-display text-lg font-semibold text-foreground">Order Summary</h2>
              <div className="space-y-3 max-h-60 overflow-y-auto">
                {items.map(item => (
                  <div key={`${item.product.id}-${item.selectedSize}-${item.selectedColor}`} className="flex gap-3">
                    <img src={item.product.images[0]} alt={item.product.name} className="w-14 h-16 object-cover rounded" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground truncate">{item.product.name}</p>
                      <p className="text-xs text-muted-foreground">{item.selectedSize} · {item.selectedColor} × {item.quantity}</p>
                      <p className="text-sm font-semibold text-primary">{formatPrice(item.product.discountedPrice * item.quantity)}</p>
                    </div>
                  </div>
                ))}
              </div>
              <div className="border-t border-border pt-3 space-y-2 text-sm">
                <div className="flex justify-between"><span className="text-muted-foreground">Subtotal</span><span className="text-foreground">{formatPrice(totalPrice)}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Delivery</span><span className="text-foreground">{formatPrice(deliveryFee)}</span></div>
                {codFee > 0 && <div className="flex justify-between"><span className="text-muted-foreground">COD Fee ({codFeePercent}%)</span><span className="text-foreground">{formatPrice(codFee)}</span></div>}
                <div className="flex justify-between pt-2 border-t border-border text-base font-semibold">
                  <span className="text-foreground">Total</span>
                  <span className="text-primary">{formatPrice(grandTotal)}</span>
                </div>
              </div>
              <Button type="submit" disabled={loading} className="w-full gradient-gold text-primary-foreground font-medium" size="lg">
                {loading ? <Loader2 className="animate-spin mr-2" size={18} /> : null}
                {loading ? 'Placing Order...' : 'Place Order'}
              </Button>
            </div>
          </div>
        </form>
      </main>
      <Footer />
      <CartDrawer />
    </div>
  );
};

export default CheckoutPage;
