import { useState, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { products, categories, type Category } from '@/data/products';
import ProductCard from '@/components/ProductCard';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import CartDrawer from '@/components/CartDrawer';
import WhatsAppWidget from '@/components/WhatsAppWidget';
import { motion } from 'framer-motion';

const ShopPage = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const activeCategory = searchParams.get('category') as Category | null;
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'newest'>('featured');

  const filtered = useMemo(() => {
    let result = activeCategory ? products.filter(p => p.category === activeCategory) : [...products];
    switch (sortBy) {
      case 'price-asc': result.sort((a, b) => a.discountedPrice - b.discountedPrice); break;
      case 'price-desc': result.sort((a, b) => b.discountedPrice - a.discountedPrice); break;
      case 'newest': result.sort((a, b) => (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0)); break;
    }
    return result;
  }, [activeCategory, sortBy]);

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="container mx-auto px-4 py-8">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
          <h1 className="font-display text-3xl md:text-4xl font-bold text-foreground">
            {activeCategory ? categories.find(c => c.id === activeCategory)?.name : 'All Products'}
          </h1>
          <p className="text-muted-foreground mt-2">{filtered.length} products</p>
        </motion.div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-3 mb-8">
          <button
            onClick={() => setSearchParams({})}
            className={`px-4 py-2 rounded-full text-xs font-medium tracking-wide transition-all ${
              !activeCategory ? 'gradient-gold text-primary-foreground' : 'border border-border text-muted-foreground hover:text-foreground hover:border-foreground'
            }`}
          >
            All
          </button>
          {categories.map(cat => (
            <button
              key={cat.id}
              onClick={() => setSearchParams({ category: cat.id })}
              className={`px-4 py-2 rounded-full text-xs font-medium tracking-wide transition-all ${
                activeCategory === cat.id ? 'gradient-gold text-primary-foreground' : 'border border-border text-muted-foreground hover:text-foreground hover:border-foreground'
              }`}
            >
              {cat.name}
            </button>
          ))}

          <select
            value={sortBy}
            onChange={e => setSortBy(e.target.value as typeof sortBy)}
            className="ml-auto px-3 py-2 rounded-md border border-border bg-background text-xs text-foreground"
          >
            <option value="featured">Featured</option>
            <option value="price-asc">Price: Low → High</option>
            <option value="price-desc">Price: High → Low</option>
            <option value="newest">Newest</option>
          </select>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
          {filtered.map((p, i) => (
            <ProductCard key={p.id} product={p} index={i} />
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-20 text-muted-foreground">
            <p className="text-lg">No products found in this category.</p>
          </div>
        )}
      </main>
      <Footer />
      <CartDrawer />
      <WhatsAppWidget />
    </div>
  );
};

export default ShopPage;
