import { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { products, reviews } from '@/data/products';
import { useCart } from '@/context/CartContext';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import CartDrawer from '@/components/CartDrawer';
import WhatsAppWidget from '@/components/WhatsAppWidget';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ShoppingBag, Heart, Star, ChevronLeft, Truck, Shield, RotateCcw } from 'lucide-react';
import { motion } from 'framer-motion';

const ProductDetail = () => {
  const { slug } = useParams<{ slug: string }>();
  const product = products.find(p => p.slug === slug);
  const { addItem } = useCart();

  const sizes = product ? [...new Set(product.variants.map(v => v.size))] : [];
  const colors = product ? [...new Set(product.variants.map(v => v.color))] : [];

  const [selectedSize, setSelectedSize] = useState(sizes[0] || '');
  const [selectedColor, setSelectedColor] = useState(colors[0] || '');

  if (!product) {
    return (
      <div className="min-h-screen">
        <Navbar />
        <div className="container mx-auto px-4 py-20 text-center">
          <h1 className="font-display text-2xl text-foreground">Product not found</h1>
          <Link to="/shop" className="text-primary mt-4 inline-block">← Back to Shop</Link>
        </div>
        <Footer />
      </div>
    );
  }

  const discount = Math.round(((product.originalPrice - product.discountedPrice) / product.originalPrice) * 100);
  const formatPrice = (price: number) => `Rs. ${price.toLocaleString()}`;

  const selectedVariant = product.variants.find(
    v => v.size === selectedSize && v.color === selectedColor
  );

  const handleAddToCart = () => addItem(product, selectedSize, selectedColor);
  const handleBuyNow = () => {
    addItem(product, selectedSize, selectedColor);
    // Will navigate to checkout when implemented
  };

  // Show a few reviews for this product
  const productReviews = reviews.slice(0, 4);

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="container mx-auto px-4 py-6">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-xs text-muted-foreground mb-6">
          <Link to="/" className="hover:text-foreground transition-colors">Home</Link>
          <span>/</span>
          <Link to="/shop" className="hover:text-foreground transition-colors">Shop</Link>
          <span>/</span>
          <span className="text-foreground">{product.name}</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12">
          {/* Image */}
          <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}>
            <div className="relative overflow-hidden rounded-lg bg-card aspect-[3/4]">
              <img src={product.images[0]} alt={product.name} className="w-full h-full object-cover" width={640} height={800} />
              {product.isNew && (
                <Badge className="absolute top-4 left-4 gradient-gold text-primary-foreground border-0">NEW</Badge>
              )}
            </div>
          </motion.div>

          {/* Details */}
          <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="flex flex-col">
            <Link to="/shop" className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground mb-4 w-fit">
              <ChevronLeft size={14} /> Back to Shop
            </Link>

            <h1 className="font-display text-2xl md:text-3xl font-bold text-foreground">{product.name}</h1>

            {/* Rating */}
            <div className="flex items-center gap-2 mt-3">
              <div className="flex items-center gap-0.5">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} size={16} className={`${i < Math.round(product.rating) ? 'fill-gold text-gold' : 'text-border'}`} />
                ))}
              </div>
              <span className="text-sm text-muted-foreground">({product.reviewCount} reviews)</span>
            </div>

            {/* Price */}
            <div className="flex items-baseline gap-3 mt-4">
              <span className="text-2xl font-display font-bold text-foreground">{formatPrice(product.discountedPrice)}</span>
              <span className="text-base text-muted-foreground line-through">{formatPrice(product.originalPrice)}</span>
              <Badge variant="destructive" className="text-xs">-{discount}%</Badge>
            </div>

            <p className="text-sm text-muted-foreground leading-relaxed mt-6">{product.description}</p>

            {/* Size */}
            <div className="mt-6">
              <label className="text-xs font-semibold tracking-wider uppercase text-foreground">Size</label>
              <div className="flex flex-wrap gap-2 mt-2">
                {sizes.map(s => (
                  <button
                    key={s}
                    onClick={() => setSelectedSize(s)}
                    className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
                      selectedSize === s
                        ? 'gradient-gold text-primary-foreground'
                        : 'border border-border text-foreground hover:border-foreground'
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>

            {/* Color */}
            {colors.length > 1 && (
              <div className="mt-4">
                <label className="text-xs font-semibold tracking-wider uppercase text-foreground">Color</label>
                <div className="flex flex-wrap gap-2 mt-2">
                  {colors.map(c => (
                    <button
                      key={c}
                      onClick={() => setSelectedColor(c)}
                      className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
                        selectedColor === c
                          ? 'gradient-gold text-primary-foreground'
                          : 'border border-border text-foreground hover:border-foreground'
                      }`}
                    >
                      {c}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Stock */}
            {selectedVariant && (
              <p className={`text-xs mt-3 ${selectedVariant.stock <= 5 ? 'text-destructive' : 'text-muted-foreground'}`}>
                {selectedVariant.stock <= 5 ? `Only ${selectedVariant.stock} left!` : `${selectedVariant.stock} in stock`}
              </p>
            )}

            {/* Actions */}
            <div className="flex gap-3 mt-8">
              <Button size="lg" className="flex-1 gradient-gold text-primary-foreground font-medium tracking-wide" onClick={handleAddToCart}>
                <ShoppingBag size={18} className="mr-2" /> Add to Bag
              </Button>
              <Button size="lg" variant="outline" className="flex-1" onClick={handleBuyNow}>
                Buy Now
              </Button>
              <Button size="lg" variant="outline" className="w-12 px-0">
                <Heart size={18} />
              </Button>
            </div>

            {/* Trust badges */}
            <div className="grid grid-cols-3 gap-4 mt-8 pt-6 border-t border-border">
              {[
                { icon: Truck, label: 'Free Delivery', sub: 'Orders over Rs. 5,000' },
                { icon: Shield, label: 'Secure Checkout', sub: '100% safe payments' },
                { icon: RotateCcw, label: 'Easy Returns', sub: '7-day return policy' },
              ].map(item => (
                <div key={item.label} className="text-center">
                  <item.icon size={20} className="mx-auto text-primary mb-1" />
                  <p className="text-xs font-medium text-foreground">{item.label}</p>
                  <p className="text-[10px] text-muted-foreground">{item.sub}</p>
                </div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Reviews section */}
        <section className="mt-16 py-12 border-t border-border">
          <h2 className="font-display text-2xl font-bold text-foreground mb-8">Customer Reviews</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {productReviews.map(review => (
              <div key={review.id} className="p-5 rounded-lg bg-card border border-border">
                <div className="flex items-center gap-1 mb-2">
                  {Array.from({ length: review.rating }).map((_, j) => (
                    <Star key={j} size={14} className="fill-gold text-gold" />
                  ))}
                </div>
                <p className="text-sm text-foreground leading-relaxed">"{review.text}"</p>
                <p className="text-xs text-muted-foreground mt-3">{review.name} — {review.city}</p>
              </div>
            ))}
          </div>
        </section>
      </main>
      <Footer />
      <CartDrawer />
      <WhatsAppWidget />
    </div>
  );
};

export default ProductDetail;
