import product1 from '@/assets/product-1.jpg';
import product2 from '@/assets/product-2.jpg';
import product3 from '@/assets/product-3.jpg';
import product4 from '@/assets/product-4.jpg';
import product5 from '@/assets/product-5.jpg';
import product6 from '@/assets/product-6.jpg';

export type Category = 'men' | 'women' | 'accessories' | 'footwear' | 'undergarments';

export interface ProductVariant {
  size: string;
  color: string;
  quality: string;
  stock: number;
}

export interface Product {
  id: string;
  name: string;
  slug: string;
  description: string;
  category: Category;
  originalPrice: number;
  discountedPrice: number;
  images: string[];
  variants: ProductVariant[];
  rating: number;
  reviewCount: number;
  isFeatured: boolean;
  isNew: boolean;
}

export const categories: { id: Category; name: string; description: string }[] = [
  { id: 'women', name: 'Women', description: 'Elegant collection for her' },
  { id: 'men', name: 'Men', description: 'Refined style for him' },
  { id: 'accessories', name: 'Accessories', description: 'Complete your look' },
  { id: 'footwear', name: 'Footwear', description: 'Step in style' },
  { id: 'undergarments', name: 'Undergarments', description: 'Premium comfort' },
];

export const products: Product[] = [
  {
    id: '1',
    name: 'Floral Embroidered Kurta',
    slug: 'floral-embroidered-kurta',
    description: 'A stunning cream kurta featuring delicate floral embroidery with gold accents. Crafted from premium lawn fabric for ultimate comfort and elegance. Perfect for festive occasions and casual gatherings.',
    category: 'women',
    originalPrice: 8500,
    discountedPrice: 5950,
    images: [product1],
    variants: [
      { size: 'S', color: 'Cream', quality: 'Premium', stock: 12 },
      { size: 'M', color: 'Cream', quality: 'Premium', stock: 8 },
      { size: 'L', color: 'Cream', quality: 'Premium', stock: 5 },
      { size: 'XL', color: 'Cream', quality: 'Premium', stock: 3 },
    ],
    rating: 4.8,
    reviewCount: 124,
    isFeatured: true,
    isNew: true,
  },
  {
    id: '2',
    name: 'Classic White Shalwar Kameez',
    slug: 'classic-white-shalwar-kameez',
    description: 'Timeless white shalwar kameez with subtle silver embroidery on the collar and cuffs. Made from premium cotton for breathability and comfort.',
    category: 'men',
    originalPrice: 6500,
    discountedPrice: 4550,
    images: [product2],
    variants: [
      { size: 'M', color: 'White', quality: 'Premium', stock: 15 },
      { size: 'L', color: 'White', quality: 'Premium', stock: 10 },
      { size: 'XL', color: 'White', quality: 'Premium', stock: 7 },
    ],
    rating: 4.6,
    reviewCount: 89,
    isFeatured: true,
    isNew: false,
  },
  {
    id: '3',
    name: 'Silk Embroidered Dupatta',
    slug: 'silk-embroidered-dupatta',
    description: 'Luxurious silk dupatta with intricate gold border embroidery and delicate tassels. A versatile accessory that adds grace to any outfit.',
    category: 'accessories',
    originalPrice: 4200,
    discountedPrice: 2940,
    images: [product3],
    variants: [
      { size: 'One Size', color: 'Coral', quality: 'Premium', stock: 20 },
      { size: 'One Size', color: 'Gold', quality: 'Premium', stock: 15 },
    ],
    rating: 4.9,
    reviewCount: 67,
    isFeatured: true,
    isNew: true,
  },
  {
    id: '4',
    name: 'Handcrafted Khussa',
    slug: 'handcrafted-khussa',
    description: 'Traditional handcrafted leather khussa with gold thread embroidery. Each pair is a masterpiece of Pakistani artisanship.',
    category: 'footwear',
    originalPrice: 3800,
    discountedPrice: 2660,
    images: [product4],
    variants: [
      { size: '7', color: 'Brown', quality: 'Artisan', stock: 8 },
      { size: '8', color: 'Brown', quality: 'Artisan', stock: 12 },
      { size: '9', color: 'Brown', quality: 'Artisan', stock: 10 },
      { size: '10', color: 'Brown', quality: 'Artisan', stock: 6 },
    ],
    rating: 4.7,
    reviewCount: 45,
    isFeatured: false,
    isNew: false,
  },
  {
    id: '5',
    name: 'Floral Print Lawn Suit',
    slug: 'floral-print-lawn-suit',
    description: 'Unstitched 3-piece lawn suit with beautiful floral digital print. Premium quality fabric with a matching dupatta and trouser fabric.',
    category: 'women',
    originalPrice: 7200,
    discountedPrice: 5040,
    images: [product5],
    variants: [
      { size: 'Unstitched', color: 'Peach Floral', quality: 'Premium', stock: 25 },
      { size: 'Unstitched', color: 'Blue Floral', quality: 'Premium', stock: 18 },
    ],
    rating: 4.5,
    reviewCount: 156,
    isFeatured: true,
    isNew: false,
  },
  {
    id: '6',
    name: 'Royal Brocade Waistcoat',
    slug: 'royal-brocade-waistcoat',
    description: 'Regal brocade waistcoat featuring ornate golden patterns on a deep navy base. Perfect for formal events, weddings, and celebrations.',
    category: 'men',
    originalPrice: 5500,
    discountedPrice: 3850,
    images: [product6],
    variants: [
      { size: 'S', color: 'Navy Gold', quality: 'Premium', stock: 6 },
      { size: 'M', color: 'Navy Gold', quality: 'Premium', stock: 10 },
      { size: 'L', color: 'Navy Gold', quality: 'Premium', stock: 8 },
      { size: 'XL', color: 'Navy Gold', quality: 'Premium', stock: 4 },
    ],
    rating: 4.8,
    reviewCount: 92,
    isFeatured: true,
    isNew: true,
  },
];

export const reviews = [
  { id: 1, name: 'Ayesha K.', city: 'Lahore', rating: 5, text: 'Absolutely stunning quality! The embroidery work is exquisite. Will definitely order again.' },
  { id: 2, name: 'Ahmed R.', city: 'Karachi', rating: 5, text: 'Perfect fit and premium fabric. This is my go-to store for formal wear now.' },
  { id: 3, name: 'Fatima S.', city: 'Islamabad', rating: 4, text: 'Beautiful designs and fast delivery. The lawn suit exceeded my expectations.' },
  { id: 4, name: 'Hassan M.', city: 'Rawalpindi', rating: 5, text: 'The waistcoat I ordered was a showstopper at my cousin\'s wedding. Top-notch quality!' },
  { id: 5, name: 'Zainab A.', city: 'Faisalabad', rating: 5, text: 'Love the attention to detail. The dupatta is even more beautiful in person.' },
  { id: 6, name: 'Omar T.', city: 'Multan', rating: 4, text: 'Great customer service and the khussa are incredibly comfortable. Highly recommend!' },
  { id: 7, name: 'Sara N.', city: 'Peshawar', rating: 5, text: 'I\'ve been shopping here for months. Every piece feels luxurious and well-made.' },
  { id: 8, name: 'Ali B.', city: 'Quetta', rating: 5, text: 'Fast shipping and the packaging was gorgeous. The shalwar kameez fits perfectly.' },
];
