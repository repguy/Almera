import { Link } from 'react-router-dom';
import { ShoppingBag, Eye } from 'lucide-react';
import { motion } from 'framer-motion';
import { useCart } from '@/context/CartContext';
import type { Product } from '@/data/products';
import { Badge } from '@/components/ui/badge';

interface ProductCardProps {
  product: Product;
  index?: number;
}

const ProductCard = ({ product, index = 0 }: ProductCardProps) => {
  const { addItem } = useCart();
  const discount = Math.round(((product.originalPrice - product.discountedPrice) / product.originalPrice) * 100);

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const v = product.variants[0];
    addItem(product, v.size, v.color);
  };

  const formatPrice = (price: number) => `Rs. ${price.toLocaleString()}`;

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
    >
      <Link to={`/product/${product.slug}`} className="group block">
        <div className="relative overflow-hidden rounded-lg bg-card aspect-[3/4]">
          <img
            src={product.images[0]}
            alt={product.name}
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            loading="lazy"
            width={640}
            height={800}
          />

          {/* Badges */}
          <div className="absolute top-3 left-3 flex flex-col gap-1.5">
            {product.isNew && (
              <Badge className="gradient-gold text-primary-foreground text-[10px] font-semibold tracking-wider border-0">
                NEW
              </Badge>
            )}
            {discount > 0 && (
              <Badge variant="destructive" className="text-[10px] font-semibold tracking-wider">
                -{discount}%
              </Badge>
            )}
          </div>

          {/* Hover actions */}
          <div className="absolute inset-x-0 bottom-0 p-3 translate-y-full group-hover:translate-y-0 transition-transform duration-300">
            <div className="flex gap-2">
              <button
                onClick={handleQuickAdd}
                className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-md gradient-gold text-primary-foreground text-xs font-semibold tracking-wide transition-opacity"
              >
                <ShoppingBag size={14} />
                Add to Bag
              </button>
              <div className="w-10 h-10 rounded-md bg-background/90 backdrop-blur-sm flex items-center justify-center text-foreground">
                <Eye size={16} />
              </div>
            </div>
          </div>
        </div>

        <div className="mt-3 space-y-1">
          <h3 className="text-sm font-medium text-foreground truncate group-hover:text-primary transition-colors">
            {product.name}
          </h3>
          <div className="flex items-center gap-2">
            <span className="text-sm font-semibold text-foreground">{formatPrice(product.discountedPrice)}</span>
            {discount > 0 && (
              <span className="text-xs text-muted-foreground line-through">{formatPrice(product.originalPrice)}</span>
            )}
          </div>
          <div className="flex items-center gap-1">
            {Array.from({ length: 5 }).map((_, i) => (
              <svg
                key={i}
                className={`w-3 h-3 ${i < Math.round(product.rating) ? 'text-gold' : 'text-border'}`}
                fill="currentColor"
                viewBox="0 0 20 20"
              >
                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
              </svg>
            ))}
            <span className="text-[10px] text-muted-foreground ml-1">({product.reviewCount})</span>
          </div>
        </div>
      </Link>
    </motion.div>
  );
};

export default ProductCard;
