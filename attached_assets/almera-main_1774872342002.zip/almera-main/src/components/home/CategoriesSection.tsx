import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import catMen from '@/assets/cat-men.jpg';
import catWomen from '@/assets/cat-women.jpg';
import catAccessories from '@/assets/cat-accessories.jpg';
import catFootwear from '@/assets/cat-footwear.jpg';

const cats = [
  { img: catWomen, label: 'Women', to: '/shop?category=women' },
  { img: catMen, label: 'Men', to: '/shop?category=men' },
  { img: catAccessories, label: 'Accessories', to: '/shop?category=accessories' },
  { img: catFootwear, label: 'Footwear', to: '/shop?category=footwear' },
];

const CategoriesSection = () => (
  <section className="py-20">
    <div className="container mx-auto px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-center mb-12"
      >
        <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground">
          Shop by Category
        </h2>
        <p className="text-muted-foreground mt-3 max-w-md mx-auto">
          Explore our curated collections for every occasion
        </p>
      </motion.div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
        {cats.map((cat, i) => (
          <motion.div
            key={cat.label}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
          >
            <Link to={cat.to} className="group block relative overflow-hidden rounded-lg aspect-[3/4]">
              <img
                src={cat.img}
                alt={cat.label}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                loading="lazy"
                width={640}
                height={800}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-charcoal/70 via-transparent to-transparent" />
              <div className="absolute inset-x-0 bottom-0 p-4 md:p-6">
                <h3 className="font-display text-lg md:text-xl font-semibold text-cream">
                  {cat.label}
                </h3>
                <span className="text-xs text-cream/70 tracking-wider uppercase group-hover:text-gold-light transition-colors">
                  Explore →
                </span>
              </div>
            </Link>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default CategoriesSection;
