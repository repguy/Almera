import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import heroImg from '@/assets/hero-fashion.jpg';

const HeroSection = () => (
  <section className="relative min-h-[85vh] flex items-center overflow-hidden">
    {/* Background image */}
    <div className="absolute inset-0">
      <img src={heroImg} alt="Almera Collection" className="w-full h-full object-cover" width={1920} height={1080} />
      <div className="absolute inset-0 bg-gradient-to-r from-charcoal/80 via-charcoal/50 to-transparent" />
    </div>

    <div className="relative container mx-auto px-4 py-20">
      <div className="max-w-xl">
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="text-gold-light text-sm font-medium tracking-[0.3em] uppercase mb-4"
        >
          New Collection 2026
        </motion.p>
        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="font-display text-4xl md:text-6xl lg:text-7xl font-bold leading-[1.1] text-cream mb-6"
        >
          Where Tradition Meets{' '}
          <span className="italic text-gold-light">Elegance</span>
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="text-cream/70 text-base md:text-lg leading-relaxed mb-8 max-w-md"
        >
          Discover premium Pakistani clothing crafted with love, artistry, and generations of heritage.
        </motion.p>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          className="flex flex-wrap gap-4"
        >
          <Button asChild size="lg" className="gradient-gold text-primary-foreground font-medium tracking-wide px-8">
            <Link to="/shop">
              Shop Now <ArrowRight size={18} className="ml-2" />
            </Link>
          </Button>
          <Button asChild size="lg" variant="outline" className="border-cream/30 text-cream hover:bg-cream/10">
            <Link to="/shop?category=women">Women's Collection</Link>
          </Button>
        </motion.div>
      </div>
    </div>
  </section>
);

export default HeroSection;
