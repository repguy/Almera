import { reviews } from '@/data/products';
import { Star } from 'lucide-react';

const ReviewMarquee = () => {
  const doubled = [...reviews, ...reviews];

  return (
    <section className="py-16 overflow-hidden">
      <div className="container mx-auto px-4 mb-10 text-center">
        <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground">
          What Our Customers Say
        </h2>
        <p className="text-muted-foreground mt-3">Join thousands of happy customers across Pakistan</p>
      </div>

      <div className="relative">
        <div className="absolute left-0 top-0 bottom-0 w-20 bg-gradient-to-r from-background to-transparent z-10" />
        <div className="absolute right-0 top-0 bottom-0 w-20 bg-gradient-to-l from-background to-transparent z-10" />

        <div className="flex animate-marquee hover:[animation-play-state:paused]">
          {doubled.map((review, i) => (
            <div
              key={`${review.id}-${i}`}
              className="flex-shrink-0 w-[320px] mx-3 p-6 rounded-lg bg-card border border-border"
            >
              <div className="flex items-center gap-1 mb-3">
                {Array.from({ length: review.rating }).map((_, j) => (
                  <Star key={j} size={14} className="fill-gold text-gold" />
                ))}
              </div>
              <p className="text-sm text-foreground leading-relaxed mb-4">"{review.text}"</p>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full gradient-gold flex items-center justify-center text-xs font-bold text-primary-foreground">
                  {review.name.charAt(0)}
                </div>
                <div>
                  <p className="text-xs font-semibold text-foreground">{review.name}</p>
                  <p className="text-[10px] text-muted-foreground">{review.city}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ReviewMarquee;
