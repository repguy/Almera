import { Link } from 'react-router-dom';

const Footer = () => (
  <footer className="bg-charcoal text-cream">
    <div className="container mx-auto px-4 py-16">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
        <div>
          <h3 className="font-display text-2xl font-bold tracking-wide mb-4">
            Almera<span className="text-gold">.</span>
          </h3>
          <p className="text-sm text-cream/60 leading-relaxed">
            Premium Pakistani clothing & accessories. Where tradition meets contemporary elegance.
          </p>
        </div>
        <div>
          <h4 className="font-display text-sm font-semibold tracking-wider uppercase mb-4">Shop</h4>
          <ul className="space-y-2 text-sm text-cream/60">
            <li><Link to="/shop?category=women" className="hover:text-gold transition-colors">Women</Link></li>
            <li><Link to="/shop?category=men" className="hover:text-gold transition-colors">Men</Link></li>
            <li><Link to="/shop?category=accessories" className="hover:text-gold transition-colors">Accessories</Link></li>
            <li><Link to="/shop?category=footwear" className="hover:text-gold transition-colors">Footwear</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="font-display text-sm font-semibold tracking-wider uppercase mb-4">Support</h4>
          <ul className="space-y-2 text-sm text-cream/60">
            <li><Link to="/legal/terms" className="hover:text-gold transition-colors">Terms of Service</Link></li>
            <li><Link to="/legal/privacy" className="hover:text-gold transition-colors">Privacy Policy</Link></li>
            <li><Link to="/legal/refund" className="hover:text-gold transition-colors">Refund Policy</Link></li>
            <li><Link to="/track-order" className="hover:text-gold transition-colors">Track Order</Link></li>
            <li><a href="https://wa.me/923001234567" className="hover:text-gold transition-colors">Contact Us</a></li>
          </ul>
        </div>
        <div>
          <h4 className="font-display text-sm font-semibold tracking-wider uppercase mb-4">Stay Connected</h4>
          <p className="text-sm text-cream/60 mb-4">Get exclusive offers and updates.</p>
          <div className="flex">
            <input
              type="email"
              placeholder="Your email"
              className="flex-1 px-4 py-2.5 bg-charcoal-light border border-cream/20 rounded-l-md text-sm text-cream placeholder:text-cream/40 focus:outline-none focus:border-gold"
            />
            <button className="px-4 py-2.5 gradient-gold text-primary-foreground text-sm font-medium rounded-r-md">
              Join
            </button>
          </div>
        </div>
      </div>
      <div className="mt-12 pt-8 border-t border-cream/10 text-center text-xs text-cream/40">
        © {new Date().getFullYear()} Almera. All rights reserved. Crafted with love in Pakistan.
      </div>
    </div>
  </footer>
);

export default Footer;
