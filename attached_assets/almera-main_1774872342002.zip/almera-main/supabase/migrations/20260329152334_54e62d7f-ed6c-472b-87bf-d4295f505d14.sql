
-- Orders table
CREATE TABLE public.orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  order_number text UNIQUE NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','confirmed','shipped','out_for_delivery','delivered','cancelled')),
  payment_method text NOT NULL CHECK (payment_method IN ('cod','easypaisa','bank_transfer')),
  payment_status text NOT NULL DEFAULT 'pending' CHECK (payment_status IN ('pending','verified','rejected')),
  payment_screenshot_url text,
  subtotal integer NOT NULL DEFAULT 0,
  delivery_fee integer NOT NULL DEFAULT 0,
  cod_fee integer NOT NULL DEFAULT 0,
  total integer NOT NULL DEFAULT 0,
  customer_name text NOT NULL,
  customer_email text,
  customer_phone text NOT NULL,
  shipping_address text NOT NULL,
  shipping_city text NOT NULL,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Order items
CREATE TABLE public.order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid REFERENCES public.orders(id) ON DELETE CASCADE NOT NULL,
  product_id text NOT NULL,
  product_name text NOT NULL,
  product_image text,
  size text NOT NULL,
  color text NOT NULL,
  quantity integer NOT NULL DEFAULT 1,
  unit_price integer NOT NULL,
  total_price integer NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Site settings (key-value)
CREATE TABLE public.site_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text UNIQUE NOT NULL,
  value text NOT NULL DEFAULT '',
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Legal pages
CREATE TABLE public.legal_pages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text UNIQUE NOT NULL,
  title text NOT NULL,
  content text NOT NULL DEFAULT '',
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Storage bucket for payment screenshots
INSERT INTO storage.buckets (id, name, public) VALUES ('payment-screenshots', 'payment-screenshots', false);

-- Enable RLS
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.site_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.legal_pages ENABLE ROW LEVEL SECURITY;

-- Orders: users can view their own, admins can view all
CREATE POLICY "Users can view own orders" ON public.orders FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Users can insert orders" ON public.orders FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Admins can view all orders" ON public.orders FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can update orders" ON public.orders FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin'));

-- Allow guest orders (anon insert)
CREATE POLICY "Anyone can place orders" ON public.orders FOR INSERT TO anon WITH CHECK (true);

-- Order items: viewable if you can see the order
CREATE POLICY "Users can view own order items" ON public.order_items FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.orders WHERE orders.id = order_items.order_id AND orders.user_id = auth.uid()));
CREATE POLICY "Users can insert order items" ON public.order_items FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Admins can view all order items" ON public.order_items FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Anyone can insert order items" ON public.order_items FOR INSERT TO anon WITH CHECK (true);

-- Site settings: everyone can read, admins can update
CREATE POLICY "Anyone can read site settings" ON public.site_settings FOR SELECT TO public USING (true);
CREATE POLICY "Admins can update site settings" ON public.site_settings FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can insert site settings" ON public.site_settings FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Legal pages: everyone can read, admins can manage
CREATE POLICY "Anyone can read legal pages" ON public.legal_pages FOR SELECT TO public USING (true);
CREATE POLICY "Admins can update legal pages" ON public.legal_pages FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can insert legal pages" ON public.legal_pages FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Storage: anyone can upload payment screenshots, admins can read all
CREATE POLICY "Anyone can upload payment screenshots" ON storage.objects FOR INSERT TO public WITH CHECK (bucket_id = 'payment-screenshots');
CREATE POLICY "Admins can view payment screenshots" ON storage.objects FOR SELECT TO authenticated USING (bucket_id = 'payment-screenshots' AND public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Users can view own screenshots" ON storage.objects FOR SELECT TO authenticated USING (bucket_id = 'payment-screenshots' AND (storage.foldername(name))[1] = auth.uid()::text);

-- Trigger for updated_at on orders
CREATE TRIGGER update_orders_updated_at BEFORE UPDATE ON public.orders
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_site_settings_updated_at BEFORE UPDATE ON public.site_settings
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_legal_pages_updated_at BEFORE UPDATE ON public.legal_pages
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Seed default site settings
INSERT INTO public.site_settings (key, value) VALUES
  ('easypaisa_name', 'Almera Store'),
  ('easypaisa_number', '03001234567'),
  ('bank_name', 'Meezan Bank'),
  ('bank_account_title', 'Almera Store'),
  ('bank_account_number', '1234567890'),
  ('bank_iban', 'PK00MEZN0000001234567890'),
  ('delivery_fee', '200'),
  ('cod_fee_percent', '10'),
  ('whatsapp_number', '923001234567'),
  ('orders_paused', 'false'),
  ('sale_active', 'false'),
  ('sale_percent', '0');

-- Seed legal pages
INSERT INTO public.legal_pages (slug, title, content) VALUES
  ('terms', 'Terms of Service', '<h2>Terms of Service</h2><p>Welcome to Almera. By using our website, you agree to these terms.</p><h3>Orders & Payment</h3><p>All orders are subject to availability. Prices are listed in Pakistani Rupees (PKR). We accept Cash on Delivery (with a 10% handling fee), Easypaisa, and Bank Transfer.</p><h3>Shipping</h3><p>We deliver across Pakistan. Standard delivery takes 3-7 business days depending on your location.</p><h3>Contact</h3><p>For questions, reach us via WhatsApp.</p>'),
  ('privacy', 'Privacy Policy', '<h2>Privacy Policy</h2><p>Your privacy matters to us at Almera.</p><h3>Information We Collect</h3><p>We collect your name, phone number, email, and shipping address to process orders. Payment screenshots are stored securely.</p><h3>How We Use Your Data</h3><p>Your data is used solely for order processing and delivery. We never share your information with third parties for marketing.</p><h3>Security</h3><p>All data is stored securely with encryption at rest.</p>'),
  ('refund', 'Refund & Exchange Policy', '<h2>Refund & Exchange Policy</h2><p>We want you to love your Almera purchase.</p><h3>Returns</h3><p>Items can be returned within 7 days of delivery if they are unused and in original packaging.</p><h3>Exchanges</h3><p>Size exchanges are free. Contact us via WhatsApp with your order number.</p><h3>Refunds</h3><p>Refunds are processed within 5-7 business days after we receive the returned item.</p>');

-- Generate order number function
CREATE OR REPLACE FUNCTION public.generate_order_number()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.order_number := 'ALM-' || to_char(now(), 'YYMMDD') || '-' || upper(substring(NEW.id::text from 1 for 6));
  RETURN NEW;
END;
$$;

CREATE TRIGGER set_order_number BEFORE INSERT ON public.orders
  FOR EACH ROW EXECUTE FUNCTION public.generate_order_number();
